<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// import Joomla view library
require_once JPATH_SITE.DS."components".DS."com_travelentity".DS."TravelEntityViewLItem.php";
 
class TravelEntityViewRegion extends TravelEntityViewLItem
{
}
