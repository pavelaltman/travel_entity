<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

require_once JPATH_SITE.DS."components".DS."com_travelentity".DS."TravelEntityControllerLItem.php";

class TravelEntityControllerPointType extends TravelEntityControllerLItem
{
}
