<?php
// No direct access to this file
defined('_JEXEC') or die;
jimport('joomla.application.component.controllerform');

class TravelEntityControllerDescr extends JControllerForm
{
}
