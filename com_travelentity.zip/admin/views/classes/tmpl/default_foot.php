<?php
// No direct access to this file
defined('_JEXEC') or die;
?>
<tr>
  <td colspan="6"><?php echo $this->pagination->getListFooter(); ?></td>
</tr>
